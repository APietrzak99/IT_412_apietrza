from functions.namefunction import *

name = input("what is your name? ")
age = input("what is your age? ")

some_func(name,age)