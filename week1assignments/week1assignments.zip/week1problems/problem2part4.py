import functions.namefunction as functions_module

name = input("what is your name? ")
age = input("what is your age? ")

functions_module.some_func(name,age)