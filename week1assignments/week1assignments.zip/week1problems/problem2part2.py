from functions.namefunction import some_func

name = input("what is your name? ")
age = input("what is your age? ")

some_func(name,age)