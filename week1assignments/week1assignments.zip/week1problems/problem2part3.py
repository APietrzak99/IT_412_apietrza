from functions.namefunction import some_func as print_name

name = input("what is your name? ")
age = input("what is your age? ")

print_name(name,age)