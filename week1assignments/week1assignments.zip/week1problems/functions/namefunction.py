def some_func(name,age):
    print("your name is: " + name +". Your age is: " + age + "." )