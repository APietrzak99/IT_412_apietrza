class shirt():
	def __init__(self,size,color):
		self.size = size
		self.color = color

	def shirtInfo(self):
		print(self.color + " " + self.size)