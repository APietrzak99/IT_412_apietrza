college_records = []

class Person():
    """a simple class meant to represent a person"""
    def __init__(self,passed_id,passed_name,passed_email):
        """initialize name, email, id variables and attributes """
        self.passed_id = passed_id
        self.passed_name = passed_name
        self.passed_email = passed_email
