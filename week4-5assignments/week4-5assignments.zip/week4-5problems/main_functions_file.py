from functions.function_library import *

course_info()

semester_info()

print(course_list)